import 'package:flutter/material.dart';

void main() => runApp(const GonmeiApp());

const purple = Color(0xFFB58AF5);
const background = Color(0xFF10121B);
const surface = Color(0xFF202230);

class GonmeiApp extends StatelessWidget {
  const GonmeiApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Gonmei Official Topup',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: background,
        colorScheme: const ColorScheme.dark(
          primary: purple,
          surface: surface,
        ),
        useMaterial3: true,
        appBarTheme: const AppBarTheme(
          backgroundColor: background,
          foregroundColor: Colors.white,
          elevation: 0,
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: surface,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide.none,
          ),
        ),
      ),
      home: const StoreHome(),
    );
  }
}

class GameProduct {
  final String name;
  final String subtitle;
  final IconData icon;
  final List<String> packages;
  const GameProduct(this.name, this.subtitle, this.icon, this.packages);
}

const products = [
  GameProduct('PUBG / BGMI UC', 'UC top-up', Icons.sports_esports,
      ['60 UC', '325 UC', '660 UC', '1800 UC']),
  GameProduct('Mobile Legends', 'Diamond top-up', Icons.auto_awesome,
      ['86 Diamonds', '172 Diamonds', '257 Diamonds', '706 Diamonds']),
  GameProduct('Clash of Clans', 'Gems and offers', Icons.castle,
      ['80 Gems', '500 Gems', '1200 Gems', '2500 Gems']),
  GameProduct('Other Games', 'Request another game', Icons.gamepad,
      ['Custom top-up', 'Request a game']),
];

class StoreOrder {
  final String game, package, playerId, payment;
  String status;
  StoreOrder({
    required this.game,
    required this.package,
    required this.playerId,
    required this.payment,
    this.status = 'Awaiting payment integration',
  });
}

class StoreHome extends StatefulWidget {
  const StoreHome({super.key});
  @override
  State<StoreHome> createState() => _StoreHomeState();
}

class _StoreHomeState extends State<StoreHome> {
  int tab = 0;
  final List<StoreOrder> orders = [];

  void openProduct(GameProduct product) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ProductPage(
          product: product,
          onOrder: (order) => setState(() => orders.insert(0, order)),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      _home(),
      _catalog(),
      _orders(),
      _account(),
    ];
    return Scaffold(
      appBar: AppBar(
        title: Row(children: [
          const Icon(Icons.bolt, color: purple, size: 28),
          const SizedBox(width: 8),
          const Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('GONMEI', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.4)),
              Text('OFFICIAL TOPUP', style: TextStyle(fontSize: 9, color: purple, letterSpacing: 2)),
            ],
          ),
        ]),
        actions: [
          IconButton(
            tooltip: 'Orders',
            onPressed: () => setState(() => tab = 2),
            icon: const Icon(Icons.receipt_long),
          )
        ],
      ),
      body: SafeArea(child: pages[tab]),
      bottomNavigationBar: NavigationBar(
        backgroundColor: const Color(0xFF171925),
        indicatorColor: purple.withOpacity(.18),
        selectedIndex: tab,
        onDestinationSelected: (v) => setState(() => tab = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.grid_view), label: 'Games'),
          NavigationDestination(icon: Icon(Icons.inventory_2_outlined), label: 'Orders'),
          NavigationDestination(icon: Icon(Icons.person_outline), label: 'Account'),
        ],
      ),
    );
  }

  Widget _home() => ListView(
    padding: const EdgeInsets.all(18),
    children: [
      Container(
        padding: const EdgeInsets.all(22),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(24),
          gradient: const LinearGradient(
            colors: [Color(0xFF38294F), Color(0xFF211E34)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('PREMIUM TOP-UP STORE', style: TextStyle(color: purple, fontSize: 11, letterSpacing: 1.4)),
          SizedBox(height: 14),
          Text('Power Up\nYour Game.', style: TextStyle(fontSize: 32, fontWeight: FontWeight.w900, height: 1.05)),
          SizedBox(height: 10),
          Text('Your gaming journey starts here.', style: TextStyle(color: Colors.white70)),
          SizedBox(height: 18),
          Row(children: [Icon(Icons.shield_outlined, color: purple), SizedBox(width: 7), Text('Secure checkout coming soon')]),
        ]),
      ),
      const SizedBox(height: 24),
      const Text('Popular categories', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      const SizedBox(height: 12),
      ...products.map(_productTile),
    ],
  );

  Widget _catalog() => ListView(
    padding: const EdgeInsets.all(18),
    children: [
      const Text('Game shop', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
      const SizedBox(height: 14),
      ...products.map(_productTile),
    ],
  );

  Widget _productTile(GameProduct p) => Card(
    color: surface,
    margin: const EdgeInsets.only(bottom: 12),
    child: ListTile(
      contentPadding: const EdgeInsets.all(14),
      leading: CircleAvatar(
        backgroundColor: purple.withOpacity(.15),
        child: Icon(p.icon, color: purple),
      ),
      title: Text(p.name, style: const TextStyle(fontWeight: FontWeight.bold)),
      subtitle: Text(p.subtitle),
      trailing: const Icon(Icons.chevron_right, color: purple),
      onTap: () => openProduct(p),
    ),
  );

  Widget _orders() => orders.isEmpty
      ? const Center(child: Text('No orders yet. Choose a game to get started.'))
      : ListView(
          padding: const EdgeInsets.all(18),
          children: [
            const Text('My orders', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            ...orders.map((o) => Card(
              color: surface,
              child: ListTile(
                title: Text(o.game),
                subtitle: Text('${o.package} • Player ID: ${o.playerId}\n${o.status}'),
                isThreeLine: true,
                leading: const Icon(Icons.receipt, color: purple),
              ),
            )),
          ],
        );

  Widget _account() => ListView(
    padding: const EdgeInsets.all(20),
    children: const [
      Text('My account', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
      SizedBox(height: 16),
      Card(
        color: surface,
        child: ListTile(
          leading: Icon(Icons.support_agent, color: purple),
          title: Text('Customer support'),
          subtitle: Text('WhatsApp / phone: 9233170503'),
        ),
      ),
      SizedBox(height: 12),
      Text('Sign-in, profile management and account security will be connected with Firebase.',
        style: TextStyle(color: Colors.white60)),
    ],
  );
}

class ProductPage extends StatefulWidget {
  final GameProduct product;
  final ValueChanged<StoreOrder> onOrder;
  const ProductPage({super.key, required this.product, required this.onOrder});

  @override
  State<ProductPage> createState() => _ProductPageState();
}

class _ProductPageState extends State<ProductPage> {
  String? selectedPackage;
  final playerController = TextEditingController();
  final serverController = TextEditingController();
  String payment = 'UPI';
  bool submitted = false;

  @override
  void dispose() {
    playerController.dispose();
    serverController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(widget.product.name)),
    body: ListView(
      padding: const EdgeInsets.all(18),
      children: [
        Text(widget.product.subtitle, style: const TextStyle(color: purple)),
        const SizedBox(height: 16),
        const Text('Choose package', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        ...widget.product.packages.map((p) => Card(
          color: selectedPackage == p ? const Color(0xFF332744) : surface,
          child: RadioListTile<String>(
            value: p,
            groupValue: selectedPackage,
            activeColor: purple,
            title: Text(p),
            subtitle: const Text('Price to be configured'),
            onChanged: (v) => setState(() => selectedPackage = v),
          ),
        )),
        const SizedBox(height: 18),
        const Text('Player details', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        TextField(
          controller: playerController,
          decoration: const InputDecoration(labelText: 'Player ID', hintText: 'Enter your game Player ID'),
          onChanged: (_) => setState(() {}),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: serverController,
          decoration: const InputDecoration(labelText: 'Server / Zone ID (if required)', hintText: 'Enter server or zone ID'),
        ),
        const SizedBox(height: 18),
        const Text('Payment preference', style: TextStyle(fontWeight: FontWeight.bold)),
        DropdownButtonFormField<String>(
          value: payment,
          dropdownColor: surface,
          items: const [
            DropdownMenuItem(value: 'UPI', child: Text('UPI')),
            DropdownMenuItem(value: 'Payment gateway', child: Text('Payment gateway')),
          ],
          onChanged: (v) => setState(() => payment = v ?? 'UPI'),
        ),
        const SizedBox(height: 18),
        const Text('Demo checkout only. No payment is collected and no game currency is delivered.',
          style: TextStyle(color: Colors.amber, fontSize: 12)),
        const SizedBox(height: 12),
        FilledButton(
          onPressed: selectedPackage == null || playerController.text.trim().isEmpty || submitted
              ? null
              : () {
                  widget.onOrder(StoreOrder(
                    game: widget.product.name,
                    package: selectedPackage!,
                    playerId: playerController.text.trim(),
                    payment: payment,
                  ));
                  setState(() => submitted = true);
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Demo order created. Payment is not active yet.')),
                  );
                },
          child: Text(submitted ? 'Demo order submitted' : 'Place demo order'),
        ),
      ],
    ),
  );
}
