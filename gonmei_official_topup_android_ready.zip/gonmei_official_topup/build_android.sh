#!/usr/bin/env bash
set -euo pipefail
if ! command -v flutter >/dev/null 2>&1; then
  echo "Flutter was not found. Install Flutter and add it to PATH." >&2
  exit 1
fi
flutter create --platforms=android --org com.gonmei .
flutter pub get
flutter analyze
flutter build apk --release
echo "APK created at build/app/outputs/flutter-apk/app-release.apk"
