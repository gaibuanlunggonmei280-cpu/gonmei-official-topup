@echo off
setlocal
where flutter >nul 2>nul
if errorlevel 1 (
  echo Flutter was not found. Install Flutter and add it to PATH.
  exit /b 1
)
flutter create --platforms=android --org com.gonmei . || exit /b 1
flutter pub get || exit /b 1
flutter analyze || exit /b 1
flutter build apk --release || exit /b 1
echo.
echo APK created at build\app\outputs\flutter-apk\app-release.apk
